/**
 * Created by Rahul Gururaj on 5/6/2017.
 */
public class Job {
    public Node source;
    public Node destination;

    public Job(Node source, Node destination) {
        this.source = source;
        this.destination = destination;
    }
}
